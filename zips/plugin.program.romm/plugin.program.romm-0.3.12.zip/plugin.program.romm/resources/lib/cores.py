# -*- coding: utf-8 -*-
"""Map RomM platform slugs to Kodi game.libretro.* add-ons."""
import os
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui

from . import kodi

TABLE_FILE = kodi.data_file('platform_cores.json')
USER_FILE = kodi.profile_file('platform_cores_user.json')
DECLINED_CONTROLLERS_FILE = kodi.profile_file('controllers_declined.json')

# preferred launch file types, best first
LAUNCH_PRIORITY = ['m3u', 'cue', 'chd', 'gdi', 'pbp', 'ccd', 'toc', 'rvz', 'wbfs', 'gcz', 'ciso', 'iso',
                   'img', 'lst', 'bin', 'mdf', 'cdi', 'nrg', 'exe', 'elf', 'dol', 'wad', 'nds', 'gba', 'gbc', 'gb',
                   'sfc', 'smc', 'nes', 'fds', 'z64', 'n64', 'v64', 'md', 'gen', 'smd', 'sms', 'gg', 'pce',
                   'sgx', 'ws', 'wsc', 'ngp', 'ngc', 'vb', 'lnx', 'a26', 'a52', 'a78', 'j64', 'jag', 'rom',
                   'col', 'int', 'vec', 'o2', 'dsk', 'adf', 'st', 'msa', 'd64', 't64', 'tap', 'prg', 'zip',
                   '7z', 'conf', 'bat', 'com', 'pak']

_table = None
_core_exts = {}


def table():
    global _table
    if _table is None:
        _table = kodi.read_json(TABLE_FILE, {}) or {}
        _table.setdefault('platforms', {})
        _table.setdefault('aliases', {})
    return _table


def canonical_slug(slug):
    slug = (slug or '').lower()
    return table()['aliases'].get(slug, slug)


def platform_key(slug, fs_slug=None):
    """Table key for a RomM platform: its folder when the table knows it (RomM files naomi as arcade)."""
    fs = canonical_slug(fs_slug)
    return fs if fs in table()['platforms'] else slug


def rom_platform(rom):
    return platform_key(rom.get('platform_slug'), rom.get('platform_fs_slug'))


def platform_entry(slug):
    return table()['platforms'].get(canonical_slug(slug))


def mapped_cores(slug):
    entry = platform_entry(slug)
    return list(entry.get('cores', [])) if entry else []


def extensions(slug):
    """Known playable extensions for a platform, or None when unknown."""
    entry = platform_entry(slug)
    exts = entry.get('extensions') if entry else None
    return set(e.lower().lstrip('.') for e in exts) if exts else None


def core_extensions(core_id):
    """Extensions the installed core's addon.xml lists (what Kodi opens it for), or None if unknown."""
    if core_id not in _core_exts:
        exts = None
        result = kodi.jsonrpc('Addons.GetAddonDetails', addonid=core_id, properties=['path']) or {}
        try:
            root = ET.parse(os.path.join((result.get('addon') or {})['path'], 'addon.xml')).getroot()
            text = root.findtext("extension[@point='kodi.gameclient']/extensions") or ''
            exts = set(e.strip().lower().lstrip('.') for e in text.split('|') if e.strip() not in ('', '/')) or None
            if exts and '*' in exts:                     # Kodi: any file
                exts = None
        except (KeyError, TypeError, OSError, ET.ParseError):
            pass
        _core_exts[core_id] = exts
    return _core_exts[core_id]


def keeps_archives(slug):
    """True when the platform's cores load their archives whole (DOSBox Pure, Flycast's arcade sets)."""
    entry = platform_entry(slug)
    return bool(entry and entry.get('keep_archives'))


def installed_clients():
    result = kodi.jsonrpc('Addons.GetAddons', type='kodi.gameclient', enabled=True) or {}
    return set(a['addonid'] for a in result.get('addons', []) or [])


def _clients(**params):
    result = kodi.jsonrpc('Addons.GetAddons', type='kodi.gameclient', properties=['name'], **params) or {}
    return {a['addonid']: a.get('name') or a['addonid'] for a in result.get('addons', []) or []}


def available_clients():
    """{core id: name} for game clients Kodi can install or enable here."""
    return dict(_clients(installed=False), **_clients(enabled=False))


def _controllers(installed):
    result = kodi.jsonrpc('Addons.GetAddons', type='kodi.game.controller', installed=installed) or {}
    return set(a['addonid'] for a in result.get('addons', []) or [])


def installed_controllers():
    return _controllers(True)


def first_port_controllers(core_id):
    """Controller profiles the core's first controller port accepts, in its topology.xml's order."""
    result = kodi.jsonrpc('Addons.GetAddonDetails', addonid=core_id, properties=['path']) or {}
    try:
        root = ET.parse(os.path.join((result.get('addon') or {})['path'], 'resources', 'topology.xml')).getroot()
    except (KeyError, TypeError, OSError, ET.ParseError):
        return []
    for port in root.findall('port'):
        if port.get('type') not in ('keyboard', 'mouse'):    # game.libretro reads no type as controller
            return [a.get('controller') for a in port.findall('accepts') if a.get('controller')]
    return []


def install_controllers(core_ids):
    """Offer a profile for each core whose first port has none; Kodi doesn't for its built-in cores."""
    declined = set(kodi.read_json(DECLINED_CONTROLLERS_FILE, []) or [])
    for core_id in core_ids:
        accepted = first_port_controllers(core_id)
        if not accepted or declined.intersection(accepted) or installed_controllers().intersection(accepted):
            continue
        installable = _controllers(False)
        wanted = next((c for c in accepted if c in installable), None)
        if not wanted:                                   # no repository has one: nothing to offer
            continue
        xbmc.executebuiltin('InstallAddon({})'.format(wanted), True)
        if wanted not in installed_controllers():
            kodi.log('controller profile {} not installed for {}'.format(wanted, core_id))
            declined.add(wanted)
            kodi.write_json(DECLINED_CONTROLLERS_FILE, sorted(declined))
            return


def user_choices():
    return kodi.read_json(USER_FILE, {}) or {}


def set_user_choice(slug, core_id):
    choices = user_choices()
    slug = canonical_slug(slug)
    if core_id:
        choices[slug] = core_id
    else:
        choices.pop(slug, None)
    kodi.write_json(USER_FILE, choices)


def reset_user_choices():
    kodi.write_json(USER_FILE, {})
    kodi.write_json(DECLINED_CONTROLLERS_FILE, [])


def candidates(slug, installed=None, choices=None):
    """Installed cores for a platform, best first. User choice wins."""
    installed = installed_clients() if installed is None else installed
    cores = [c for c in mapped_cores(slug) if c in installed]
    choice = (user_choices() if choices is None else choices).get(canonical_slug(slug))
    if choice and choice in installed:
        cores = [choice] + [c for c in cores if c != choice]
    return cores


def installable(slug, available=None, choices=None):
    """Mapped cores Kodi can install or enable, best first. User choice first."""
    available = available_clients() if available is None else available
    cores = mapped_cores(slug)
    choice = (user_choices() if choices is None else choices).get(canonical_slug(slug))
    if choice in cores:
        cores = [choice] + [c for c in cores if c != choice]
    return [c for c in cores if c in available]


def install(core_id):
    """Kodi's own install (or enable) prompt; True once the core is usable."""
    disabled = _clients(enabled=False)
    builtin = 'EnableAddon' if core_id in disabled else 'InstallAddon'
    xbmc.executebuiltin('{}({})'.format(builtin, core_id), True)
    if core_id in installed_clients():
        return True
    if core_id in disabled:                              # declined, or Kodi refused (incompatible)
        kodi.error(kodi.L(30637), disabled[core_id])
    return False


def offer_install(slug, name):
    """No core installed: offer the best one Kodi can get. True once installed."""
    if not mapped_cores(slug):
        xbmcgui.Dialog().ok(name, kodi.L(30636, slug))
        return False
    cores = installable(slug)
    if not cores:
        xbmcgui.Dialog().ok(kodi.L(30611, name), kodi.L(30612))
        return False
    return install(cores[0])


def install_for_platform(slug, name):
    """Context menu: first core as at launch, or pick another one to add."""
    if not candidates(slug):
        return offer_install(slug, name)
    available = available_clients()
    cores = installable(slug, available)
    if not cores:
        return False
    idx = xbmcgui.Dialog().select('{}: {}'.format(kodi.L(30036), name), [available[c] for c in cores])
    return idx >= 0 and install(cores[idx])


def is_supported(slug, installed=None, choices=None):
    return bool(candidates(slug, installed, choices))


def core_label(core_id):
    result = kodi.jsonrpc('Addons.GetAddonDetails', addonid=core_id, properties=['name']) or {}
    return (result.get('addon') or {}).get('name') or core_id


def choose_for_platform(slug, platform_name=''):
    mapped = mapped_cores(slug)
    if not mapped:
        kodi.error(kodi.L(30636, slug))
        return
    installed = installed_clients()
    cores = [c for c in mapped if c in installed]
    if not cores:
        offer_install(slug, platform_name or slug)
        return
    labels = [kodi.L(30013)] + [core_label(c) for c in cores]
    current = user_choices().get(canonical_slug(slug))
    preselect = cores.index(current) + 1 if current in cores else 0
    idx = xbmcgui.Dialog().select('{}: {}'.format(kodi.L(30010), platform_name or slug), labels, preselect=preselect)
    if idx < 0:
        return
    set_user_choice(slug, cores[idx - 1] if idx > 0 else None)
