# -*- coding: utf-8 -*-
"""Local download cache: <root>/<rom_id>/<files>, plus BIOS mirror under <root>/bios."""
import os
import re
import shutil
import time
import zipfile
from urllib.parse import quote

import xbmcvfs

from . import kodi
from .api import ApiError
from .cores import LAUNCH_PRIORITY

MARKER = '.romm.json'
EXTRACTED = '.romm-extracted'
ARCHIVE_EXTS = {'zip', '7z'}
# disc images, which a core that reads zips (Saturn's, for ST-V sets) can't read from one
DISC_EXTS = {'cue', 'chd', 'iso', 'gdi', 'ccd', 'toc', 'mds', 'cdi', 'pbp', 'm3u', 'cso', 'ciso', 'zso',
             'rvz', 'wbfs', 'gcz'}
CHUNK = 4 << 20
SKIP_CATEGORIES = {'manual', 'walkthrough', 'patch', 'cheat', 'soundtrack', 'screenshot'}


def root():
    path = os.path.expanduser(xbmcvfs.translatePath(kodi.setting('cache_path').strip()))
    if '://' in path:                                    # network VFS: plain file I/O can't use it
        kodi.log('cache_path {} is not a local folder, using the add-on data folder'.format(path))
        path = ''
    if not path:
        path = os.path.join(kodi.PROFILE, 'cache')
    return kodi.ensure_dir(os.path.normpath(path))


def safe_join(base, *parts):
    """Join server-supplied names under base, refusing anything that escapes it."""
    base = os.path.normpath(base)
    path = os.path.normpath(os.path.join(base, *parts))
    if path != base and not path.startswith(base + os.sep):
        raise ValueError('unsafe path from server: {}'.format(os.path.join(*parts)))
    return path


def rom_dir(rom_id):
    return os.path.join(root(), str(int(rom_id)))


def marker_path(rom_id):
    return os.path.join(rom_dir(rom_id), MARKER)


def remember_launch(rom_id, path, keep=False, core=None):
    """The file and core handed to RetroPlayer, so a later save sync looks for the same ones.
    keep: the core writes progress into the game files, so eviction must leave them."""
    m = marker(rom_id)
    if m and (m.get('launch') != path or m.get('core') != core or (keep and not m.get('keep'))):
        m['launch'] = path
        m['core'] = core
        m['keep'] = bool(keep or m.get('keep'))
        kodi.write_json(marker_path(rom_id), m)


def keeps_progress(path, core_ids):
    """True when this file can hold progress: a core that writes into its game files, and not an
    archive or CD image, which those cores never write to."""
    from . import saves
    ext = _ext(path)
    return ext not in ARCHIVE_EXTS and (ext == 'm3u' or ext not in DISC_EXTS) and saves.writes_content(core_ids)


def is_kept(rom_id):
    """True when the game's own files may hold progress, so it is never removed unasked."""
    m = marker(rom_id) or {}
    if 'launch' in m:
        return bool(m.get('keep'))
    # not launched by this version: judge by the platform's cores, as a launch would
    from . import cores
    mapped = cores.mapped_cores(cores.platform_key(m.get('platform_slug'), m.get('platform_fs_slug')))
    return any(keeps_progress(f, mapped) for f in m.get('files') or [])


def kept_ids():
    return set(rid for _mtime, rid in entries() if is_kept(rid))


def is_cached(rom_id):
    return os.path.exists(marker_path(rom_id))


def rom_id_for_path(path):
    """Map a file inside the cache (e.g. the path RetroPlayer is playing) back to its ROM id."""
    try:
        rel = os.path.relpath(os.path.realpath(path), os.path.realpath(root()))
    except (ValueError, OSError):
        return None
    head = rel.split(os.sep, 1)[0]
    return int(head) if head.isdigit() else None


def marker(rom_id):
    return kodi.read_json(marker_path(rom_id))


def cached_ids():
    base = root()
    return set(int(n) for n in os.listdir(base) if n.isdigit() and os.path.exists(os.path.join(base, n, MARKER)))


def _ext(name):
    return os.path.splitext(name)[1].lstrip('.').lower()


def _game_files(rom):
    files = [f for f in (rom.get('files') or []) if (f.get('category') or 'game') not in SKIP_CATEGORIES]
    return files


def _relative_name(rom, rom_file):
    base = (rom.get('full_path') or '').rstrip('/') + '/'
    full = rom_file.get('full_path') or ''
    if base and full.startswith(base) and rom.get('has_multiple_files'):
        return full[len(base):]
    return rom_file['file_name']


def ensure_rom(rom, client, progress=None):
    """Download every game file of a ROM. Returns (directory, [local paths])."""
    rid = rom['id']
    directory = rom_dir(rid)
    marker = kodi.read_json(marker_path(rid))
    if marker and marker.get('fs_name') == rom.get('fs_name') and all(os.path.exists(p) for p in marker.get('files', [])):
        _touch(rid)
        return directory, marker['files']

    kodi.ensure_dir(directory)
    kept = is_kept(rid)                                 # its files may hold progress: fetch only what's missing
    files = _game_files(rom)
    local = []
    if rom.get('has_multiple_files') and files:
        subdir = safe_join(directory, rom.get('fs_name_no_ext') or rom.get('fs_name') or 'game')
        total = len(files)
        for i, f in enumerate(files, 1):
            dest = safe_join(subdir, _relative_name(rom, f).replace('/', os.sep))
            if not (os.path.exists(dest) and (kept or os.path.getsize(dest) == (f.get('file_size_bytes') or -1))):
                client.download(client.rom_file_url(f), dest, f.get('file_size_bytes'),
                                progress and (lambda d, t, i=i, n=f['file_name']: progress(d, t, i, total, n)))
            local.append(dest)
    else:
        name = rom.get('fs_name') or (files[0]['file_name'] if files else str(rid))
        dest = safe_join(directory, name)
        size = rom.get('fs_size_bytes')
        if not (os.path.exists(dest) and (kept or size and os.path.getsize(dest) == size)):
            url = client.rom_file_url(files[0]) if len(files) == 1 else client.rom_content_url(rom)
            client.download(url, dest, size, progress and (lambda d, t: progress(d, t, 1, 1, name)))
        local.append(dest)

    new = {'rom_id': rid, 'fs_name': rom.get('fs_name'), 'name': rom.get('name'),
           'platform_slug': rom.get('platform_slug'), 'platform_fs_slug': rom.get('platform_fs_slug'),
           'files': local, 'downloaded': int(time.time())}
    if kept:
        new.update(keep=True, launch=(marker or {}).get('launch'), core=(marker or {}).get('core'))
    kodi.write_json(marker_path(rid), new)
    return directory, local


def extract_if_needed(local_files, supported_exts, progress=None, keep_archives=False):
    """Unpack a single archive unless the platform's cores read it as it is."""
    if len(local_files) != 1 or _ext(local_files[0]) not in ARCHIVE_EXTS:
        return local_files
    archive = local_files[0]
    target = os.path.splitext(archive)[0]
    if os.path.exists(os.path.join(target, EXTRACTED)):
        return _walk(target)
    native = bool(supported_exts) and _ext(archive) in supported_exts
    if native and keep_archives:
        return local_files
    zipped = _ext(archive) == 'zip'
    names = _zip_names(archive) if zipped else _vfs_names(archive)
    if native and not DISC_EXTS & set(map(_ext, names)):
        return local_files
    if not names:
        raise ApiError(kodi.L(30638 if zipped else 30639, os.path.basename(archive)))
    if zipped:
        if progress:
            progress(0, 1, 1, 1, os.path.basename(archive))
        with zipfile.ZipFile(archive) as z:
            for member in z.infolist():
                if _inside(target, member.filename):
                    z.extract(member, target)
    else:
        _vfs_extract(archive, names, target, progress)
    extracted = _walk(target)
    if extracted:
        with open(os.path.join(target, EXTRACTED), 'w'):
            pass
        os.remove(archive)
        marker = kodi.read_json(os.path.join(os.path.dirname(archive), MARKER))
        if marker:
            marker['files'] = extracted
            kodi.write_json(os.path.join(os.path.dirname(archive), MARKER), marker)
    return extracted or local_files


def _inside(target, name):
    """False for a member that would land outside target (path traversal)."""
    dest = os.path.normpath(os.path.join(target, name))
    return dest.startswith(os.path.normpath(target) + os.sep)


def _zip_names(archive):
    with zipfile.ZipFile(archive) as z:
        return [m.filename for m in z.infolist() if not m.is_dir()]


def _vfs_url(archive, name=''):
    return 'archive://' + quote(archive, safe='') + '/' + name


def _vfs_names(archive, rel=''):
    """Files in an archive that Kodi reads through vfs.libarchive, as relative paths."""
    try:
        dirs, files = xbmcvfs.listdir(_vfs_url(archive, rel))
    except (OSError, RuntimeError):
        return []
    names = [rel + f for f in files]
    for d in dirs:
        names += _vfs_names(archive, rel + d + '/')
    return names


def _vfs_extract(archive, names, target, progress):
    for index, name in enumerate(names, 1):
        if not _inside(target, name):
            continue
        dest = os.path.join(target, *name.split('/'))
        kodi.ensure_dir(os.path.dirname(dest))
        src = xbmcvfs.File(_vfs_url(archive, name))
        try:
            total, done = src.size(), 0
            with open(dest + '.part', 'wb') as out:
                while True:
                    data = src.readBytes(CHUNK)
                    if not data:
                        break
                    out.write(data)
                    done += len(data)
                    if progress and progress(done, total, index, len(names), os.path.basename(name)) is False:
                        raise ApiError('cancelled')
        finally:
            src.close()
        # nothing at all also means Kodi couldn't open the member
        if done != total or not done:
            raise ApiError(kodi.L(30638, os.path.basename(archive)))
        os.replace(dest + '.part', dest)


def _walk(directory):
    out = []
    for base, _dirs, names in os.walk(directory):
        out.extend(os.path.join(base, n) for n in names if not n.startswith('.'))
    return sorted(out)


def pick_launch_file(local_files, supported_exts=None):
    """Choose the file to hand to RetroPlayer, writing an .m3u for multi-disc sets."""
    if not local_files:
        return None
    if len(local_files) == 1:
        return local_files[0]
    by_ext = {}
    for f in local_files:
        by_ext.setdefault(_ext(f), []).append(f)
    playlists = not supported_exts or 'm3u' in supported_exts      # PSP, 3DO, PC-FX cores read none
    if playlists and by_ext.get('m3u'):
        return sorted(by_ext['m3u'])[0]
    discs = by_ext.get('cue') or by_ext.get('chd') or by_ext.get('gdi') or by_ext.get('pbp') or []
    if playlists and len(discs) > 1:
        return write_m3u(discs)
    for ext in LAUNCH_PRIORITY:
        if by_ext.get(ext) and (not supported_exts or ext in supported_exts):
            return sorted(by_ext[ext])[0]
    if supported_exts:
        for f in local_files:
            if _ext(f) in supported_exts:
                return f
    return max(local_files, key=os.path.getsize)


def _natural(name):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', name)]


def write_m3u(discs):
    discs = sorted(discs, key=_natural)
    directory = os.path.dirname(discs[0])
    prefix = os.path.commonprefix([os.path.splitext(os.path.basename(d))[0] for d in discs])
    base = re.sub(r'[\s(\[\-_]*(disc|disk|cd|side)?[\s(\[\-_]*$', '', prefix, flags=re.I) or 'game'
    path = os.path.join(directory, base + '.m3u')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(os.path.relpath(d, directory) for d in discs) + '\n')
    return path


def _touch(rom_id):
    try:
        os.utime(marker_path(rom_id), None)
    except OSError:
        pass


def dir_size(path):
    total = 0
    for base, _dirs, names in os.walk(path):
        for n in names:
            try:
                total += os.path.getsize(os.path.join(base, n))
            except OSError:
                pass
    return total


def entries():
    out = []
    for name in os.listdir(root()):
        if not name.isdigit():
            continue
        marker = os.path.join(root(), name, MARKER)
        if os.path.exists(marker):
            out.append((os.path.getmtime(marker), int(name)))
    return sorted(out)


def remove(rom_id):
    shutil.rmtree(rom_dir(rom_id), ignore_errors=True)


def evict(keep_rom_id=None):
    pct = kodi.setting_int('cache_limit_pct')
    if pct <= 0:
        return
    size = dir_size(root())
    limit = (size + shutil.disk_usage(root()).free) * pct // 100   # share of cache plus free space
    held = False
    for _mtime, rid in entries():
        if size <= limit:
            break
        if rid == keep_rom_id:
            continue
        if is_kept(rid):                                # its progress lives in its files
            held = True
            continue
        size -= dir_size(rom_dir(rid))
        kodi.log('evicting rom {} from cache'.format(rid))
        remove(rid)
    if size > limit and held:
        kodi.log('cache over its limit: games keeping progress in their files were not evicted')
        kodi.notify(kodi.L(30643))


def clear(keep=()):
    for name in os.listdir(root()):
        if name.isdigit() and int(name) in keep:
            continue
        path = os.path.join(root(), name)
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        else:
            os.remove(path)
