# -*- coding: utf-8 -*-
"""Background service: runs the media proxy while Kodi is up."""
import xbmc

from . import kodi, proxy
from .api import FrigateClient


class Monitor(xbmc.Monitor):
    def __init__(self, server):
        super().__init__()
        self.server = server
        self.onSettingsChanged()

    def onSettingsChanged(self):
        self.server.client = FrigateClient(kodi.fresh_setting('server_url'), kodi.fresh_setting('username'),
                                           kodi.fresh_setting('password'), kodi.fresh_setting('token'),
                                           timeout=proxy.TIMEOUT)


def run():
    server = proxy.start()
    if server is None:
        return
    monitor = Monitor(server)
    try:
        monitor.waitForAbort()
    finally:
        proxy.stop(server)
