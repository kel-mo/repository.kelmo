# -*- coding: utf-8 -*-
"""Ken Burns screensaver: the slideshow viewer, photos only, until Kodi wakes up."""
import random

import xbmc

from . import kodi, plugin, viewer
from .api import ApiError, ImmichClient

SOURCES = ('memories', 'random', 'favourites', 'search', 'albums', 'random_album')
ALBUM_SOURCES = ('albums', 'random_album')


def photos(client, source, **params):
    return [a for a in plugin.source_assets(client, dict(params, source=source)) if a['image']]


def in_order(source):
    return source in ALBUM_SOURCES and not kodi.setting_bool('screensaver_shuffle')


def album_photos(client):
    chosen = [i for i in kodi.setting('screensaver_albums').split(',') if i]
    if in_order('albums'):                      # albums by date, each one's photos in the chosen photo order
        dates = {a['id']: a.get('startDate') or '' for a in client.albums()}
        chosen.sort(key=lambda i: dates.get(i, ''), reverse=plugin.newest_first())
        start = random.randrange(len(chosen)) if chosen else 0
        chosen = chosen[start:] + chosen[:start]    # a random one first, as one large album can fill hours
    found = {}
    for album_id in chosen:
        try:
            found.update((a['id'], a) for a in photos(client, 'album', album_id=album_id))
        except ApiError as e:                   # album gone since it was picked
            kodi.log('screensaver: album {}: {}'.format(album_id, e), xbmc.LOGWARNING)
    return list(found.values())


def random_album_photos(client, skip=None):
    """(album id, photos) of a random album other than skip; (skip, []) when there's no other."""
    albums = [a for a in client.albums() if a.get('assetCount') and a['id'] != skip]
    random.shuffle(albums)
    for a in albums:                            # some hold only videos
        found = photos(client, 'album', album_id=a['id'])
        if found:
            kodi.debug('screensaver: album {}'.format(a.get('albumName')))
            return a['id'], found
    return skip, []


def next_albums(client, album_id, mixed):
    """Another random album each time the viewer nears the end of one, so one album doesn't play over and over."""
    current = [album_id]

    def more():
        current[0], found = random_album_photos(client, skip=current[0])
        if mixed:
            random.shuffle(found)
        return found
    return more


def run():
    try:
        client = ImmichClient()
        source = SOURCES[min(max(kodi.setting_int('screensaver_source'), 0), len(SOURCES) - 1)]
        query = kodi.setting('screensaver_query').strip()
        more = None
        if source == 'albums':
            assets = album_photos(client)
        elif source == 'random_album':
            album_id, assets = random_album_photos(client)
            more = next_albums(client, album_id, not in_order(source))
        else:
            assets = photos(client, source, query=query) if source != 'search' or query else []
        if not assets and source != 'random':      # nothing on this day, no favourites, matches or albums
            source, assets = 'random', photos(client, 'random')
    except ApiError as e:
        kodi.log('screensaver: {}'.format(e), xbmc.LOGWARNING)
        return
    if not in_order(source):
        random.shuffle(assets)
    viewer.play(client, assets, more=client.random if source == 'random' else more, screensaver=True)
